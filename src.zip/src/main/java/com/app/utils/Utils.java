package com.app.utils;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import com.google.api.client.googleapis.auth.oauth2.GoogleBrowserClientRequestUrl;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.googleapis.auth.oauth2.GoogleTokenResponse;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.people.v1.PeopleService;
import com.google.api.services.people.v1.PeopleServiceScopes;
import com.google.api.services.people.v1.model.ListConnectionsResponse;
import com.google.api.services.people.v1.model.Person;

public class Utils {
	
private static final Map<String,Function<String,String>> map;
private static final Map<String,Function<Map<String,String>,ResponseEntity<String>>> postCallmap;
private static final Map<String,Function<String,String>> fetchDatamap;
private static final Map<String,String> datamap;
	
	static
	{
		
		datamap = new HashMap<String, String>();
		datamap.put("google_id", "355702574650-p3d0dj5urm9bghls8qk0rfcic7g6gaj2.apps.googleusercontent.com");
		datamap.put("google_secret", "EFo05h91VTIQgVn-MZUJhcp6");
		datamap.put("jira_id", "X5HlpxkKWgEnoLKX0ZNAGkCTcBN43INv");
		datamap.put("jira_secret", "mvjq-QgImb7rRm_k5QJwFs0sryLwXwLtFIk5QDiIDoQrEvDnZsjqQsFI35XtlDs5");
		datamap.put("github_id", "9647494c6d55774479e1");
		datamap.put("github_secret", "3c3a9c09672e159d81a3c24f3e56ef0465b66d9a");
		datamap.put("redirectUrl", "http://localhost:8888/general/general_oauth_redirect");
		
		map = new HashMap<String,Function<String,String>>();
		map.put("GOOGLE", (sid) -> {
			String authorizationUrl = new GoogleBrowserClientRequestUrl(datamap.get("google_id"), datamap.get("redirectUrl"),
					Arrays.asList(PeopleServiceScopes.CONTACTS,PeopleServiceScopes.PLUS_LOGIN)).build();
			return authorizationUrl;
		});
		
		map.put("JIRA", (sid) -> {
			String authorizationUrl = "https://auth.atlassian.com/authorize?audience=api.atlassian.com&client_id="+datamap.get("jira_id")+"&scope=read:jira-user&redirect_uri="+datamap.get("redirectUrl")+"&state="+sid+"&response_type=code&prompt=consent";
			return authorizationUrl;
		});
		
		map.put("GITHUB", (sid) -> {
			String authorizationUrl = "https://github.com/login/oauth/authorize?client_id="+datamap.get("github_id")+"&redirect_uri="+datamap.get("redirectUrl")+"&login=&scope=read:user&state="+sid+"&allow_signup=true"; 
			return authorizationUrl;
		});
		
		postCallmap = new HashMap<String,Function<Map<String,String>,ResponseEntity<String>>>();
		postCallmap.put("GITHUB", valuesMap -> {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
			String url = "https://github.com/login/oauth/access_token";
			MultiValueMap<String, String> map= new LinkedMultiValueMap<String, String>();
			map.add("client_id", datamap.get("github_id"));
			map.add("client_secret", datamap.get("github_secret"));
			map.add("code", valuesMap.get("code"));
			map.add("redirect_uri", "http://localhost:8888/general/general_oauth_redirect");
			map.add("state", valuesMap.get("state"));
			HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<MultiValueMap<String, String>>(map, headers);
			RestTemplate restTemplate = new RestTemplate();
			ResponseEntity<String> recievedResponse = restTemplate.postForEntity( url, request , String.class );
			return recievedResponse;
		});
		
		fetchDatamap = new HashMap<String, Function<String,String>>();
		fetchDatamap.put("GOOGLE", access_token -> {
			try {
				return fetchDataGoogle(access_token);
			} catch (IOException e) {
				e.printStackTrace();
				return null;
			}
		});
		
		fetchDatamap.put("GITHUB", access_token -> {
			try {
				return fetchDataGitHub(access_token);
			} catch (IOException e) {
				e.printStackTrace();
				return null;
			}
		});
		
	}
	
	public static String landProcess(String name,String state) 
	{
		return map.get(name).apply(state);
	}
	
	public static ResponseEntity<String> postForToken(Map<String,String> params)
	{
		
		return postCallmap.get(params.get("site")).apply(params);
	}
	
	public static String fetchData(String site,String access_token)
	{
		return fetchDatamap.get(site).apply(access_token);
	}
	
	public static String fetchDataGoogle(String access_token) throws IOException {
		HttpTransport httpTransport = new NetHttpTransport();
		JacksonFactory jsonFactory = new JacksonFactory();
		GoogleTokenResponse tokenResponse = new GoogleTokenResponse().setAccessToken(access_token);
		GoogleCredential credential = new GoogleCredential.Builder().setTransport(httpTransport)
				.setJsonFactory(jsonFactory).setClientSecrets(datamap.get("google_id"), datamap.get("google_secret")).build()
				.setFromTokenResponse(tokenResponse);
		PeopleService peopleService = new PeopleService.Builder(httpTransport, jsonFactory, credential).build();
		ListConnectionsResponse connectionResponse = peopleService.people().connections().list("people/me").setPersonFields("names,emailAddresses").execute();
		List<Person> connections = connectionResponse.getConnections();
		return connections.toString();
	}
	
	public static String fetchDataGitHub(String access_token) throws IOException {
		
		RestTemplate restTemplate = new RestTemplate();
	    String result = restTemplate.getForObject("https://api.github.com/user?"+access_token, String.class);
		return result;
	}

}
