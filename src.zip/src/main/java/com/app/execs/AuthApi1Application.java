package com.app.execs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthApi1Application {

	public static void main(String[] args) {
		SpringApplication.run(AuthApi1Application.class, args);
	}

}
