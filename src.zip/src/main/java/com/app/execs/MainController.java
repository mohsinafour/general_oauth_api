package com.app.execs;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.app.utils.Utils;


@Controller
@RequestMapping("/general")
public class MainController {
	
	@GetMapping("/")
	public String home()
	{
		return "home";
	}

	@GetMapping("/request_data")
	@ResponseBody
	public void landGet(@RequestParam String name, HttpServletResponse response,HttpSession hs) throws IOException {
		hs.setMaxInactiveInterval(3600);
		hs.setAttribute("site", name.toUpperCase());
		response.sendRedirect(Utils.landProcess(name.toUpperCase(), hs.getId()));
	}
	
	@GetMapping("general_oauth_redirect")
	public String authoris(@RequestParam(value="code",required=false) String code,
			@RequestParam(value="state",required=false) String state, HttpServletResponse response,HttpSession hs) throws IOException
	{
		if(code==null)
		{
			return "redirect";
		}
		else 
		{
			Map<String,String> params = new HashMap<>();
			params.put("code", code);
			params.put("state", state);
			params.put("site", hs.getAttribute("site").toString());
			ResponseEntity<String> recievedResponse = Utils.postForToken(params);
			hs.setAttribute("access_response_"+hs.getAttribute("site").toString(), recievedResponse);
			return "redirect";
			
		} 
	}

	@SuppressWarnings("unchecked")
	@GetMapping("general_oauth_redirected")
	@ResponseBody
	public void authorised(@RequestParam(value="access_token",required=false) String access_token, HttpServletResponse response, HttpServletRequest request,HttpSession hs) throws IOException {
		if(access_token!=null)
		{
			System.out.println(Utils.fetchData(hs.getAttribute("site").toString(), access_token));
		}
		else
		{
			String x = ((ResponseEntity<String>) hs.getAttribute("access_response_"+hs.getAttribute("site").toString())).getBody();
			System.out.println(Utils.fetchData(hs.getAttribute("site").toString(), x.substring(x.indexOf("access_token"), x.indexOf("&"))));
		}
		response.sendRedirect("http://localhost:8888/general/test");
	}
	
	@GetMapping("test")
	public String testing() {
		return "end";
	}

}
